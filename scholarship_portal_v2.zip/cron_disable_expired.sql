
-- Optional: if pg_cron is enabled in your Supabase project:
create extension if not exists pg_cron;

select cron.schedule(
  'disable-expired-scholarships',
  '5 0 * * *',
  $$ update public.scholarships
     set active = false, updated_at = now()
     where active = true
       and deadline is not null
       and deadline < current_date; $$
);
